export type Region = {
  id: string; regionName: string; state: string; geographicLevel: 'District (illustrative)'; population: number; reportingDate: string;
  waterStorageMCM: number; usableWaterMCM: number; waterReserveMCM: number;
  rainfallActualMM: number; rainfallNormalMM: number; foodStockMT: number; foodReserveMT: number; foodDemandMTPerDay: number;
  agricultureWaterDemandMLD: number; industryWaterDemandMLD: number; householdWaterDemandMLD: number;
  waterTransferInfrastructureAvailable: boolean; foodTransportAvailable: boolean;
  waterTransferCapacityMLD: number; foodTransferCapacityMT: number;
  sourceName: string; sourceType: string; dataQuality: 'High' | 'Medium' | 'Limited'; isSimulated: true;
  lat: number; lng: number;
};

const make = (id:string, regionName:string, state:string, population:number, storage:number, usable:number, reserve:number, rain:number, normal:number, food:number, foodReserve:number, daily:number, ag:number, industry:number, household:number, infra:boolean, foodRoute:boolean, waterCap:number, foodCap:number, quality:Region['dataQuality'], lat:number, lng:number):Region => ({
  id, regionName, state, geographicLevel:'District (illustrative)', population, reportingDate:'2025-06-15', waterStorageMCM:storage, usableWaterMCM:usable, waterReserveMCM:reserve,
  rainfallActualMM:rain, rainfallNormalMM:normal, foodStockMT:food, foodReserveMT:foodReserve, foodDemandMTPerDay:daily,
  agricultureWaterDemandMLD:ag, industryWaterDemandMLD:industry, householdWaterDemandMLD:household,
  waterTransferInfrastructureAvailable:infra, foodTransportAvailable:foodRoute, waterTransferCapacityMLD:waterCap, foodTransferCapacityMT:foodCap,
  sourceName:`${regionName} District Resource Cell (simulated)`, sourceType:'Illustrative planning dataset', dataQuality:quality, isSimulated:true, lat, lng,
});

export const regions:Region[] = [
  make('nashik','Nashik','Maharashtra',6100000,632,48,8,122,176,93400,16870,2410,304,116,824,true,true,36,5200,'High',19.9975,73.7898),
  make('pune','Pune','Maharashtra',9420000,508,98,18,148,191,128500,25970,3710,386,244,1272,true,true,42,7800,'High',18.5204,73.8567),
  make('jaipur','Jaipur','Rajasthan',6660000,284,23,5,58,112,78200,18410,2630,248,154,899,true,true,22,4200,'Medium',26.9124,75.7873),
  make('jodhpur','Jodhpur','Rajasthan',3680000,148,10,3,31,86,41200,10430,1490,149,91,497,false,true,0,2100,'Medium',26.2389,73.0243),
  make('indore','Indore','Madhya Pradesh',3270000,238,38,8,96,143,56800,9100,1300,162,105,442,true,true,28,3900,'High',22.7196,75.8577),
  make('bhopal','Bhopal','Madhya Pradesh',2550000,192,31,7,104,151,47700,7070,1010,119,88,344,true,true,24,3100,'Medium',23.2599,77.4126),
  make('lucknow','Lucknow','Uttar Pradesh',3740000,204,30,7,108,164,69300,12670,1810,218,132,505,true,true,31,5000,'High',26.8467,80.9462),
  make('varanasi','Varanasi','Uttar Pradesh',3680000,138,6,2,88,158,19000,8540,1220,134,79,497,true,true,19,2600,'Limited',25.3176,82.9739),
  make('nagpur','Nagpur','Maharashtra',2910000,267,45,10,117,166,52900,8470,1210,155,108,393,true,true,27,3700,'High',21.1458,79.0882),
  make('surat','Surat','Gujarat',7080000,398,62,12,70,121,91500,17430,2490,237,228,956,true,true,38,6400,'Medium',21.1702,72.8311),
  make('rajkot','Rajkot','Gujarat',1900000,108,7,2,42,109,28700,5040,720,91,67,257,false,true,0,1800,'Limited',22.3039,70.8022),
  make('coimbatore','Coimbatore','Tamil Nadu',3450000,217,36,7,164,192,49200,8120,1160,144,102,466,true,true,25,3500,'Medium',11.0168,76.9558),
];
