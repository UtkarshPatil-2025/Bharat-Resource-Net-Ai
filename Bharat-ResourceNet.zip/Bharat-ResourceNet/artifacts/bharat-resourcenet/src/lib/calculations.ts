import type { Region } from './regions.ts';

export type RiskBand = 'critical' | 'high' | 'moderate' | 'low' | 'unknown';
export type Settings = { householdLitres:number; planningDays:number };
export type RainfallRiskBands = {
  criticalDeficitMM:number;
  highDeficitMM:number;
  moderateDeficitMM:number;
};
export type RiskResult = { risk:RiskBand; reason:string };
export type Assessment = {
  householdMLD:number|null; totalWaterMLD:number|null; waterDays:number|null; foodDays:number|null;
  rainfallDepartureMM:number|null; waterShortageMCM:number|null; foodShortageMT:number|null;
  waterSurplusMCM:number|null; foodSurplusMT:number|null;
  waterRisk:RiskBand; foodRisk:RiskBand; rainfallRisk:RiskBand; overallRisk:RiskBand;
  waterReason:string; foodReason:string; rainfallReason:string; overallReason:string;
};

export const DEFAULT_RAINFALL_RISK_BANDS:RainfallRiskBands = {
  criticalDeficitMM:120,
  highDeficitMM:80,
  moderateDeficitMM:40,
};
const valid = (n:number) => Number.isFinite(n) && n >= 0;
const priority:Record<RiskBand,number> = {unknown:-1,low:0,moderate:1,high:2,critical:3};

export function riskBand(days:number|null):RiskBand {
  if (days === null || !Number.isFinite(days) || days < 0) return 'unknown';
  if (days < 7) return 'critical';
  if (days < 14) return 'high';
  if (days <= 30) return 'moderate';
  return 'low';
}
export function waterRisk(usableSupplyDays:number|null):RiskBand {
  return riskBand(usableSupplyDays);
}
export function foodRisk(stockDays:number|null):RiskBand {
  return riskBand(stockDays);
}
export function rainfallRisk(departureMM:number|null,bands:RainfallRiskBands=DEFAULT_RAINFALL_RISK_BANDS):RiskBand {
  if (departureMM===null||!Number.isFinite(departureMM)) return 'unknown';
  const values=[bands.criticalDeficitMM,bands.highDeficitMM,bands.moderateDeficitMM];
  if (!values.every(v=>Number.isFinite(v)&&v>=0)||!(bands.criticalDeficitMM>bands.highDeficitMM&&bands.highDeficitMM>bands.moderateDeficitMM)) return 'unknown';
  if (departureMM<=-bands.criticalDeficitMM) return 'critical';
  if (departureMM<=-bands.highDeficitMM) return 'high';
  if (departureMM<=-bands.moderateDeficitMM) return 'moderate';
  return 'low';
}
export function overallRisk(water:RiskBand,food:RiskBand,rainfall:RiskBand):RiskBand {
  if (water==='unknown'||food==='unknown') return 'unknown';
  const applicable=[water,food,...(rainfall==='unknown'?[]:[rainfall])];
  return applicable.reduce((highest,current)=>priority[current]>priority[highest]?current:highest,'low' as RiskBand);
}
function daysReason(resource:string,days:number|null,risk:RiskBand):string {
  if (risk==='unknown') return `Unknown: required ${resource} supply or demand inputs are missing or invalid.`;
  return `${days!.toFixed(1)} days of ${resource} at current demand; demo bands are critical <7, high 7–<14, moderate 14–30, low >30 days.`;
}
export function assessRegion(r:Region,settings:Settings,bands:RainfallRiskBands=DEFAULT_RAINFALL_RISK_BANDS):Assessment {
  const household = valid(r.population) && valid(settings.householdLitres) ? r.population*settings.householdLitres/1_000_000 : null;
  const total = household === null || !valid(r.agricultureWaterDemandMLD) || !valid(r.industryWaterDemandMLD) ? null : household+r.agricultureWaterDemandMLD+r.industryWaterDemandMLD;
  const waterDays = total === null || total === 0 || !valid(r.usableWaterMCM) ? null : r.usableWaterMCM*1000/total;
  const foodDays = !valid(r.foodStockMT) || !valid(r.foodDemandMTPerDay) || r.foodDemandMTPerDay === 0 ? null : r.foodStockMT/r.foodDemandMTPerDay;
  const departure = valid(r.rainfallActualMM) && valid(r.rainfallNormalMM) && r.rainfallNormalMM > 0 ? r.rainfallActualMM-r.rainfallNormalMM : null;
  const waterShortage = total === null || !valid(settings.planningDays) || !valid(r.usableWaterMCM) ? null : Math.max(0,total*settings.planningDays/1000-r.usableWaterMCM);
  const foodShortage = !valid(r.foodStockMT) || !valid(r.foodDemandMTPerDay) || !valid(settings.planningDays) ? null : Math.max(0,r.foodDemandMTPerDay*settings.planningDays-r.foodStockMT);
  const waterSurplus = total === null || !valid(settings.planningDays) || !valid(r.usableWaterMCM) || !valid(r.waterReserveMCM) ? null : Math.max(0,r.usableWaterMCM-r.waterReserveMCM-total*settings.planningDays/1000);
  const foodSurplus = !valid(r.foodStockMT) || !valid(r.foodDemandMTPerDay) || !valid(r.foodReserveMT) || !valid(settings.planningDays) ? null : Math.max(0,r.foodStockMT-r.foodReserveMT-r.foodDemandMTPerDay*settings.planningDays);
  const wr=waterRisk(waterDays), fr=foodRisk(foodDays), rr=rainfallRisk(departure,bands), or=overallRisk(wr,fr,rr);
  const rainfallReason = departure===null
    ? 'Unknown: actual or normal rainfall input is missing or invalid; rainfall is omitted from overall risk.'
    : `Departure ${departure>0?'+':''}${departure.toFixed(1)} mm. Illustrative deficit bands: critical ≤−${bands.criticalDeficitMM}, high ≤−${bands.highDeficitMM}, moderate ≤−${bands.moderateDeficitMM} mm; less-negative departures are low.`;
  const overallReason = or==='unknown'
    ? `Unknown overall risk because essential ${wr==='unknown'?'water':''}${wr==='unknown'&&fr==='unknown'?' and ':''}${fr==='unknown'?'food':''} inputs are unavailable.`
    : `Highest applicable component is ${or}: water ${wr}, food ${fr}${rr==='unknown'?'; rainfall unavailable and omitted':`; rainfall ${rr}`}.`;
  return {
    householdMLD:household,totalWaterMLD:total,waterDays,foodDays,rainfallDepartureMM:departure,
    waterShortageMCM:waterShortage,foodShortageMT:foodShortage,waterSurplusMCM:waterSurplus,foodSurplusMT:foodSurplus,
    waterRisk:wr,foodRisk:fr,rainfallRisk:rr,overallRisk:or,
    waterReason:daysReason('water',waterDays,wr),foodReason:daysReason('food',foodDays,fr),rainfallReason,overallReason,
  };
}
export function householdDemandMLD(population:number, litresPerPerson:number):number|null {
  return valid(population) && valid(litresPerPerson) ? population*litresPerPerson/1_000_000 : null;
}
export function transferQuantity(sourceSurplus:number,destinationShortage:number,capacity:number,resource:'water'|'food',infrastructureAvailable:boolean):number {
  if (![sourceSurplus,destinationShortage,capacity].every(valid) || !infrastructureAvailable) return 0;
  return Math.min(sourceSurplus,destinationShortage,capacity);
}
