# Bharat ResourceNet AI — demo

## Run

From the workspace root:

```sh
pnpm --filter @workspace/bharat-resourcenet dev
```

## Tests

Requires Node.js 24 (native TypeScript type stripping):

```sh
pnpm --filter @workspace/bharat-resourcenet test
```

For a production bundle and static type check:

```sh
pnpm --filter @workspace/bharat-resourcenet build
pnpm --filter @workspace/bharat-resourcenet typecheck
```

## Simulation limitations

Every regional amount, date, source descriptor, quality flag, risk assessment, and transfer suggestion is fabricated for demonstration. This is not an official or live government feed, and source descriptors are not verified. Risk thresholds are illustrative planning assumptions; rainfall deficit bands are configurable in `src/lib/calculations.ts`. Transfer recommendations are transparent rule-based calculations, not autonomous allocations. Settings and scenario changes remain in local browser storage. The interactive map uses OpenStreetMap tiles for geographic context only; plotted regional markers are illustrative locations and do not represent official boundaries.
