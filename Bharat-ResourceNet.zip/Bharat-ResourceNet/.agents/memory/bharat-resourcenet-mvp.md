---
name: Bharat ResourceNet MVP scope
description: Scope and trust constraints from the user's Bharat ResourceNet blueprint request.
---

Implement the blueprint's hackathon MVP rather than its separate full-platform scope unless asked otherwise. The MVP is frontend-only with clearly simulated regional data; do not imply live official coverage or make backend services, paid AI, or credentials mandatory. Water duration uses usable supply, not raw storage. Water transfers require explicit infrastructure, protect source reserves, and remain advisory for human review.

**Why:** The blueprint separates a short hackathon MVP from a much larger production platform, and the user asked specifically for the MVP.

**How to apply:** Keep simulation and provenance labels visible until verified data integrations are actually implemented. Recheck the blueprint before expanding beyond the MVP.
